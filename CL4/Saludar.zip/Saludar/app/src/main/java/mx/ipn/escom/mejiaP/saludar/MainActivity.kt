package mx.ipn.escom.mejiaP.saludar

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_USERNAME = "mx.ipn.escom.mejiaP.saludar.extra.USERNAME"
    }

    private val LOG_TAG = MainActivity::class.java.simpleName
    private var mMessageEditText: EditText? = null
    private var mReplyTextView: TextView? = null
    val TEXT_REQUEST:Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mMessageEditText = findViewById(R.id.edit_name)

        //Mensaje de respuesta
        mReplyTextView = findViewById(R.id.text_message_reply)
    }

    fun saludar(view: View) {
        val intent = Intent(this, SaludarActivity::class.java)
        val message:String = mMessageEditText?.text.toString()
        Log.d(LOG_TAG, message)
        intent.putExtra(EXTRA_USERNAME, message)
        //startActivity(intent)
        startActivityForResult(intent, TEXT_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent? ) {
        super.onActivityResult(requestCode, resultCode, data)
        var mensaje:String? = null
        if (requestCode == TEXT_REQUEST){
            if (resultCode == RESULT_OK){
                val reply: String? = data?.getStringExtra(SaludarActivity.EXTRA_REPLY)
                try{
                    val hour: Int? = reply?.toInt()
                    if (hour != null) {
                        mensaje = when (hour){
                            in 4..11 -> "¡Buenos días!"
                            in 12..19 -> "¡Buenas tardes!"
                            else -> "¡Buenas noches!"
                        }
                    }
                } catch (ex: java.lang.NumberFormatException){
                    mensaje = "Hola de nuevo"
                }

                mReplyTextView?.setText(mensaje)
                mReplyTextView?.setVisibility(View.VISIBLE)
            }
        }
    }
}
